function add(a, b) {
    return a + b;
}
var sum = add("JavaTPoint", 25);
console.log("Sum of no. is: " + sum);
