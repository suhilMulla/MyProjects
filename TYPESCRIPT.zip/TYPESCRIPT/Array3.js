var arr;
var i;
arr = [1, 2, 3, 4, 5];
console.log("Numeric array: ");
for (i = 0; i < arr.length; i++) {
    console.log(arr[i]);
}
arr = ["C", "C++", "Java", "HTML", "CSS"];
console.log("String array: ");
for (i = 0; i < arr.length; i++) {
    console.log(arr[i]);
}
