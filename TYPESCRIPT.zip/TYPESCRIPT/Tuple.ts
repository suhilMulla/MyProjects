let empTuple=["Rohit Sharma", 25, "MicroSoft"];
console.log("Items: "+empTuple);
console.log("Length of Tuple Items before push: "+empTuple.length);
empTuple.push(101);
console.log("Length of Tuple Items after push: "+empTuple.length);
console.log("Items: "+empTuple);