function greet(person) {
    return "Hello, " + person;
}
var user = "Suhil";
console.log(greet(user));
