function greet(person)
{
	return "Hello, "+person;
}
let user="Suhil";
console.log(greet(user));