package org.servlet;

public class UserDefined {
		
	public String demo()
	{
		return "Text from demo method";
	}
		
}
