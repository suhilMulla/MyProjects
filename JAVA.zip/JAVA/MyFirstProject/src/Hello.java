
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello");
		System.out.println("Everyone");
		System.out.println("We are here to learn Java");
		System.out.println("Its break time");

	}

}
