package Lambda;

public interface Calculable {
	
	public int Cal(int p, int t, int r);

}
