package Collections;

public class Test {

	public static void main(String[] args) {
		
		CollExample ex = new CollExample();
		ex.Hash();
		ex.Queues();

	}

}
