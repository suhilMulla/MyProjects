package org;

import java.util.Scanner;

public class testCustomer {
	public static void main(String[] main) throws Exception {
		
		OurBank ob = new OurBank();
		ob.userAuthentication();
	//	CustomerDaoImpl cdi=new CustomerDaoImpl();
	//	System.out.println("enter customer amount");
		//Scanner sc=new Scanner(System.in);
	//  int ID ;
	  //ID=sc.nextInt();
	  //cdi.viewProfile1(ID);
//	  long amount = sc.nextLong();
	//  System.out.println("enter customer ac_no");
	 // int acc_no = sc.nextInt();
	  //String un=" ";
//	String pass=" ";
	//cdi.transfer(un, pass, amount, acc_no);
	 // cdi.viewAllCustomer();
	
	
	}

}
