package MethodReferences;

public interface Sayable {
	
	void Say();

}
