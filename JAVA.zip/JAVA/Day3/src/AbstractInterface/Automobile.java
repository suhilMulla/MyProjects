package AbstractInterface;

public class Automobile {
	
	public String colour;
	public String engine;
	
	

}
