package AbstractInterface;

public class Test {

	public static void main(String[] args) {
		
		FourWheeler f = new Car();
		f.Start();
		

	}

}
