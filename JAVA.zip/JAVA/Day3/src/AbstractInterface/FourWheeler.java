package AbstractInterface;

public abstract class FourWheeler extends Automobile{
	
	//public String Type;
	public int wheels;
	
	public abstract void Start();
	

}
