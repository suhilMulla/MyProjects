package AbstractInterface;

public class Car extends FourWheeler{
	
	public String brand;
	
	public void Start()
	{
		System.out.println("The car can start only when ignition works properly");
	}

}
