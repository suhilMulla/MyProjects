package Interface;

public class Coffee extends Liquid{
	
	public void Swirl()
	{
		System.out.println("Swirling Coffee");
	}

}
