package Interface;

public interface Wash {
	
	public void wash();

}
