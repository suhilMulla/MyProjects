package Interface;

public class Milk extends Liquid{
	
	public void Swirl() 
	{
		System.out.println("Swirling Milk");
	}

}
