package Interface;

public class Liquid {
	
	public void Swirl()
	{
		System.out.println("Swirling Liquid");
	}

	

}
