package Array;

public class Test {

	public static void main(String[] args) {
		
		CPU cpu = new CPU();
		cpu.Caclulate();

	}

}
