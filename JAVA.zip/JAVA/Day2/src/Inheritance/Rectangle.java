package Inheritance;

public class Rectangle {
	public int sides = 4;
	
	public void display() 
	{
		System.out.println("Rectangle is red in colour ");
	}
	
	public void calc_area()
	{
		System.out.println("Area is l*b \n");
	}

}
