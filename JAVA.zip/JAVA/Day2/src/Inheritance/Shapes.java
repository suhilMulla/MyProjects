package Inheritance;

public class Shapes {
	public String colour;
	public String area;
	
	public void display()
	{
		System.out.println("All shapes have colour ");
	}
	
	public void calc_area()
	{
		System.out.println("Area is calculated as x*y \n");
	}

}
