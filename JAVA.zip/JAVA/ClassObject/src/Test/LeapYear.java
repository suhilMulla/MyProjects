package Test;

import java.util.Scanner;

public class LeapYear {

	public static void main(String[] args) {
		/*int year = 2000;
		if((year%4 == 0 && year%100 != 0) || year%400 == 0) {
			System.out.println(year+" is a Leap year");
		}
		else {
			System.out.println(year+" is not a Leap year");
		}
			

	}*/
		
		/*int i = 0;
		for(i = 0; i <= 10; i++)
		{
			System.out.println(i);
		}
		System.out.println("\n");
		
		for(i = 0; i <= 10; i++)
		{
			if(i % 2 ==0)
				System.out.println(i);
		}
		System.out.println("\n");
		
		for(i = 0; i <= 10; i++)
		{
			if(i % 2 != 0)
				System.out.println(i);
		}
		System.out.println("\n");
	}
}*/
		/*int a = 0;
		int b = 1;
		int sum = 0;
		int i = 0;
	
		for (i = 0; i < 45; i++)
		{
			System.out.println(a);
			sum = a + b;
			a = b;
			b = sum;
		}
	}
}*/

	/*int i = 0;
	System.out.println("Printing i");
	do {
		System.out.println(i);
		i+=2;
	}while(i < 10);
	System.out.println("\n");
		
	int x = 5;
	System.out.println("Printing x");
	while(x < 10) {
		System.out.println(x);
		x+=2;
	}*/
		
		
	/*String name;
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter your name ");
	name = scn.next();
	System.out.println("Entered Name: "+name);
	
	int age;
	System.out.println("Enter your age ");
	age = scn.nextInt();
	System.out.println("Entered Age: "+age);*/
	
		
	/*String color = "Brown";
	switch(color)
	{
		case "Green" : System.out.println("Vegan");
			break;
		case "Red" : System.out.println("Non-Veggie");
			break;
		case "Brown" : System.out.println("Eggitarian");
			break;
		default : System.out.println("N/A");
	}*/
		
		
	/*int a = 10;
	int b = 20;
	int result;
	String opt;
	System.out.println("Give the Operator");
	Scanner scn = new Scanner(System.in);
	opt = scn.next();
	switch(opt)
	{
	case "+" : result = a + b;
		System.out.println(result);
		break;
	case "-" : result = a - b;
	System.out.println(result);
		break;
	case "*" : result = a * b;
	System.out.println(result);
		break;
	case "/" : result = a / b;
	System.out.println(result);
		break;
	case "%" : result = a % b;
	System.out.println(result);
		break;
	default : System.out.println("Invalid Operator");
	
	}*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	}		

}

	
			
			
			
			 
			
			
	
		
		
		
		
		
		
		
		
		
		
		
		
