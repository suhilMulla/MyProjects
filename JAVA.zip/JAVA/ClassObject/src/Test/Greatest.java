package Test;

public class Greatest {

	public static void main(String[] args) {
		int x = 50;
		int y = 9;
		int z = 10;
		
		if(x > y && x > z) {
			 
				System.out.println("X is the Greatest number");
			}
			
	
	else if(y > x && y  > z) {
			System.out.println("Y is the Greatest number");
	  }
		else {
			System.out.println("Z is the Greatest number");
		}

	}

}
