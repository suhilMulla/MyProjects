package Org;

public class Person {
	public String name;
	public int age;
	public String place;
	
public void display()
{
	System.out.println("Person's Info: ");
	System.out.println("Name: "+name);
	System.out.println("Age: "+age);
	System.out.println("Place: "+place+"\n");
	System.out.println("Meet "+name+" he/she is from "+place+" and he/she is "+age+" years old\n");
}

}
